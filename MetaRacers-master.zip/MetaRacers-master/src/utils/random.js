export const getRandomInt = (max) => {
  return Math.floor(Math.random() * max);
}
